
import React from 'react';
import { TrendingUp } from 'lucide-react';
import EntryTable from './EntryTable';
import { VIEWS } from '../constants';
import { FinancialEntry, Theme } from '../types';

interface StocksViewProps {
    stocks: FinancialEntry[];
    selectedRegion: string;
    theme: Theme;
}

const StocksView: React.FC<StocksViewProps> = ({ stocks, selectedRegion, theme }) => {
    return (
        <div className="p-4 sm:p-8">
            <h1 className="text-4xl font-extrabold text-indigo-500 mb-6 flex items-center">
                <TrendingUp className="mr-3 h-9 w-9" />
                Stocks & Equities ({selectedRegion})
            </h1>
            <EntryTable
                title="Stock"
                headers={['Date', 'Name', 'Operation', 'Price', 'Quantity', 'Total Amount']}
                data={stocks}
                type={VIEWS.STOCKS}
                theme={theme}
            />
        </div>
    );
};

export default StocksView;