import React, { useState } from 'react';
import { Wifi } from 'lucide-react';

interface SupabaseCredentialsModalProps {
    onConnect: (url: string, key: string) => void;
    error: string | null;
    theme: string;
}

const SupabaseCredentialsModal: React.FC<SupabaseCredentialsModalProps> = ({ onConnect, error, theme }) => {
    const [url, setUrl] = useState('https://cihfadcyxahjhtzgybmf.supabase.co');
    const [key, setKey] = useState('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpaGZhZGN5eGFoamh0emd5Ym1mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjEzMTIzODEsImV4cCI6MjA3Njg4ODM4MX0.FiNjZ1y7E-eV7dCS9q8HbCIYNGJruzX59Ob71vwgXjU');
    const [isConnecting, setIsConnecting] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsConnecting(true);
        // Add a small delay to show connecting state, improves UX
        setTimeout(() => {
            onConnect(url, key);
            setIsConnecting(false);
        }, 500);
    };
    
    const isDark = theme !== 'light';
    const cardClass = isDark ? 'bg-gray-900 text-gray-50 border border-indigo-900/50' : 'bg-white text-gray-900 border border-gray-100';
    const inputClass = isDark ? 'bg-gray-800 border-gray-600 text-white' : 'bg-gray-100 border-gray-300 text-gray-900';

    return (
        <div className={`fixed inset-0 z-50 flex items-center justify-center bg-gray-950 p-4 font-sans`}>
            <div className={`w-full max-w-md rounded-xl shadow-2xl p-8 transform transition-all ${cardClass}`}>
                <div className="text-center">
                    <Wifi className="mx-auto h-12 w-12 text-indigo-500" />
                    <h2 className="mt-4 text-2xl font-bold">Connect to Supabase</h2>
                    <p className="mt-2 text-sm text-current/70">
                        Please enter your Supabase project URL and anon key to continue.
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="mt-8 space-y-6">
                    <div>
                        <label htmlFor="supabase-url" className="block text-sm font-medium text-current/80">
                            Supabase URL
                        </label>
                        <input
                            id="supabase-url"
                            name="url"
                            type="url"
                            autoComplete="off"
                            required
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            placeholder="https://your-project-ref.supabase.co"
                            className={`mt-1 block w-full rounded-md border p-3 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${inputClass}`}
                        />
                    </div>

                    <div>
                        <label htmlFor="supabase-key" className="block text-sm font-medium text-current/80">
                            Supabase Anon Key
                        </label>
                        <input
                            id="supabase-key"
                            name="key"
                            type="text"
                            autoComplete="off"
                            required
                            value={key}
                            onChange={(e) => setKey(e.target.value)}
                            placeholder="ey..."
                            className={`mt-1 block w-full rounded-md border p-3 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm ${inputClass}`}
                        />
                    </div>
                    
                    {error && <div className="p-3 bg-red-500/10 border border-red-400 text-red-400 rounded-lg text-sm">{error}</div>}

                    <div>
                        <button
                            type="submit"
                            disabled={isConnecting}
                            className="flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-3 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50"
                        >
                            {isConnecting ? 'Connecting...' : 'Save & Connect'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default SupabaseCredentialsModal;