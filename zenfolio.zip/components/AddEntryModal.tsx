
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { getSupabase } from '../services/supabase';
import { themeClasses, THEMES, CATEGORIES } from '../constants';
import { Theme } from '../types';

interface AddEntryModalProps {
    isOpen: boolean;
    onClose: () => void;
    userId: string | null;
    selectedRegion: string;
    theme: Theme;
}

const AddEntryModal: React.FC<AddEntryModalProps> = ({ isOpen, onClose, userId, selectedRegion, theme }) => {
    const classes = themeClasses[theme];
    const [entryType, setEntryType] = useState('stock');
    const [operation, setOperation] = useState('buy');
    const [formData, setFormData] = useState({ 
        name: '', price: '', quantity: '', units: '', nav: '', amount: '', category: CATEGORIES[0]
    });
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        setFormData({ name: '', price: '', quantity: '', units: '', nav: '', amount: '', category: CATEGORIES[0] });
        setError(null);
    }, [isOpen, entryType]);

    if (!isOpen || !userId) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSaveEntry = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setIsSaving(true);

        let newEntry: any = {
            user_id: userId,
            type: entryType,
            operation: operation,
            region: selectedRegion,
            name: formData.name.trim(),
        };

        try {
            if (entryType === 'stock') {
                const price = parseFloat(formData.price);
                const quantity = parseInt(formData.quantity, 10);
                if (!newEntry.name || isNaN(price) || price <= 0 || isNaN(quantity) || quantity <= 0) throw new Error("Please enter a valid stock name, price, and quantity.");
                newEntry = { ...newEntry, price, quantity };
            } else { // 'mf'
                const units = parseFloat(formData.units);
                const nav = parseFloat(formData.nav);
                const amount = parseFloat(formData.amount);
                if (!newEntry.name || isNaN(units) || units <= 0 || isNaN(nav) || nav <= 0 || isNaN(amount) || amount <= 0) throw new Error("Please enter valid mutual fund details.");
                if (!formData.category) throw new Error("Please select a valid category.");
                newEntry = { ...newEntry, units, nav, amount, category: formData.category };
            }
            
            const supabase = getSupabase();
            const { error: insertError } = await supabase.from('financial_entries').insert([newEntry]);
            if (insertError) throw insertError;
            
            onClose(); 
        } catch (err: any) {
            console.error("Failed to save entry:", err);
            setError(err.message || "An unknown error occurred during save.");
        } finally {
            setIsSaving(false);
        }
    };

    const inputClasses = `w-full p-3 rounded-lg border focus:ring-indigo-500 focus:border-indigo-500 transition-shadow text-gray-900 ${theme === THEMES.LIGHT ? 'bg-gray-100 border-gray-300' : 'bg-gray-200 border-gray-400'}`;
    const labelClasses = `block text-sm font-medium mb-1 ${theme === THEMES.LIGHT ? 'text-gray-700' : 'text-gray-300'}`;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
            <div className={`w-full max-w-lg rounded-xl shadow-2xl p-6 transform transition-all ${classes.card}`} onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center border-b pb-3 mb-4 border-current/20">
                    <h2 className="text-2xl font-bold text-indigo-500">Add New Entry</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-current/10 transition-colors">
                        <X className="h-6 w-6 text-current/70" />
                    </button>
                </div>

                <div className="mb-4 flex space-x-2">
                    <button onClick={() => setEntryType('stock')} className={`flex-1 p-3 rounded-lg font-semibold transition-all ${entryType === 'stock' ? 'bg-indigo-500 text-white shadow-md' : classes.tableHeader}`}>Stock</button>
                    <button onClick={() => setEntryType('mf')} className={`flex-1 p-3 rounded-lg font-semibold transition-all ${entryType === 'mf' ? 'bg-indigo-500 text-white shadow-md' : classes.tableHeader}`}>Mutual Fund</button>
                </div>
                <div className="mb-6 flex space-x-2">
                    <button onClick={() => setOperation('buy')} className={`flex-1 p-2 rounded-lg text-sm font-medium transition-all ${operation === 'buy' ? 'bg-green-500 text-white' : 'bg-current/10 text-current/80'}`}>Buy</button>
                    <button onClick={() => setOperation('sell')} className={`flex-1 p-2 rounded-lg text-sm font-medium transition-all ${operation === 'sell' ? 'bg-red-500 text-white' : 'bg-current/10 text-current/80'}`}>Sell</button>
                </div>
                <form onSubmit={handleSaveEntry} className="space-y-4">
                    <div>
                        <label htmlFor="name" className={labelClasses}>{entryType === 'stock' ? 'Stock Symbol/Name' : 'Fund Name'}</label>
                        <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} className={inputClasses} required />
                    </div>
                    {entryType === 'stock' && (
                        <>
                            <div>
                                <label htmlFor="price" className={labelClasses}>Price (per share)</label>
                                <input id="price" name="price" type="number" step="0.01" value={formData.price} onChange={handleChange} className={inputClasses} required />
                            </div>
                            <div>
                                <label htmlFor="quantity" className={labelClasses}>Quantity</label>
                                <input id="quantity" name="quantity" type="number" step="1" value={formData.quantity} onChange={handleChange} className={inputClasses} required />
                            </div>
                        </>
                    )}
                    {entryType === 'mf' && (
                        <>
                            <div>
                                <label htmlFor="category" className={labelClasses}>Fund Category</label>
                                <select id="category" name="category" value={formData.category} onChange={handleChange} className={inputClasses} required>
                                    {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="units" className={labelClasses}>Units</label>
                                <input id="units" name="units" type="number" step="0.001" value={formData.units} onChange={handleChange} className={inputClasses} required />
                            </div>
                            <div>
                                <label htmlFor="nav" className={labelClasses}>NAV at Transaction</label>
                                <input id="nav" name="nav" type="number" step="0.0001" value={formData.nav} onChange={handleChange} className={inputClasses} required />
                            </div>
                            <div>
                                <label htmlFor="amount" className={labelClasses}>Total Amount ($)</label>
                                <input id="amount" name="amount" type="number" step="0.01" value={formData.amount} onChange={handleChange} className={inputClasses} required />
                            </div>
                        </>
                    )}
                    {error && <div className="p-3 bg-red-500/10 border border-red-400 text-red-400 rounded-lg text-sm">{error}</div>}
                    <button type="submit" disabled={isSaving} className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition-colors disabled:opacity-50">
                        {isSaving ? 'Saving...' : `Add Entry`}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AddEntryModal;