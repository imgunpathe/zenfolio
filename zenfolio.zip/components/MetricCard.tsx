
import React from 'react';

interface MetricCardProps {
    label: string;
    value: number;
    subtext?: string;
    pnl?: number;
    pnlPercentage?: number;
    cardClass?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ label, value, subtext, pnl, pnlPercentage, cardClass }) => {
    const isProfit = pnl !== undefined && pnl >= 0;
    const pnlColor = pnl === undefined ? 'text-current/80' : isProfit ? 'text-green-500' : 'text-red-500';

    return (
        <div className={`p-6 rounded-xl shadow-lg ${cardClass}`}>
            <p className="text-sm font-medium text-current/60">{label}</p>
            <p className="mt-1 text-3xl font-bold">${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            {subtext && (
                <div className="flex items-center text-sm mt-1">
                    <span className={pnlColor}>
                        {pnl !== undefined && `${isProfit ? '+' : ''}$${pnl.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                        {pnlPercentage !== undefined && ` (${isProfit ? '+' : ''}${pnlPercentage.toFixed(2)}%)`}
                    </span>
                    <span className="ml-2 text-current/60">{subtext}</span>
                </div>
            )}
        </div>
    );
};

export default MetricCard;
