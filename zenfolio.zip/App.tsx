import React, { useState, useEffect, useMemo } from 'react';
import { Clock } from 'lucide-react';
import { RealtimeChannel } from '@supabase/supabase-js';
import { initializeSupabase, getSupabase } from './services/supabase';
import { VIEWS, THEMES, themeClasses } from './constants';
import { FinancialEntry, View, Theme } from './types';
import Navigation from './components/Navigation';
import DashboardView from './components/DashboardView';
import StocksView from './components/StocksView';
import MutualFundsView from './components/MutualFundsView';
import AddEntryModal from './components/AddEntryModal';
import SupabaseCredentialsModal from './components/SupabaseCredentialsModal';
import GeminiHelp from './components/GeminiHelp';

type SupabaseStatus = 'idle' | 'connecting' | 'connected' | 'error';

const App = () => {
    const [activeView, setActiveView] = useState<View>(VIEWS.DASHBOARD);
    const [selectedRegion, setSelectedRegion] = useState('India');
    const [entries, setEntries] = useState<FinancialEntry[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [theme, setTheme] = useState<Theme>(THEMES.DARK);
    const [userId, setUserId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [fetchError, setFetchError] = useState<string | null>(null);
    const [supabaseStatus, setSupabaseStatus] = useState<SupabaseStatus>('idle');
    
    const [supabaseCreds, setSupabaseCreds] = useState<{ url: string; key: string } | null>(null);
    const [connectionError, setConnectionError] = useState<string | null>(null);

    const classes = themeClasses[theme];

    // Load credentials from local storage on initial mount
    useEffect(() => {
        const storedUrl = localStorage.getItem('supabase_url');
        const storedKey = localStorage.getItem('supabase_key');
        if (storedUrl && storedKey) {
            setSupabaseCreds({ url: storedUrl, key: storedKey });
        } else {
            setIsLoading(false); // If no creds, stop initial loading
        }
    }, []);

    useEffect(() => {
        const getUserId = (): string => {
            let id = localStorage.getItem('zenfolio_user_id');
            if (!id) {
                id = `user_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
                localStorage.setItem('zenfolio_user_id', id);
            }
            return id;
        };
        setUserId(getUserId());
    }, []);

    const handleConnect = async (url: string, key: string) => {
        setConnectionError(null);
        setIsLoading(true);
        try {
            // Temporarily initialize to test connection
            const supabase = initializeSupabase(url, key);
            
            // Perform a lightweight test query to validate credentials
            const { error } = await supabase.from('financial_entries').select('*', { count: 'exact', head: true });

            // Check for specific authentication errors
            if (error && (error.message.includes('Invalid API key') || error.message.includes('invalid JWT'))) {
                 throw new Error('Connection failed: Invalid Supabase URL or Anon Key.');
            }
            // Other errors (like RLS) are fine, it means the connection worked.

            // If test is successful, save credentials and update state
            localStorage.setItem('supabase_url', url);
            localStorage.setItem('supabase_key', key);
            setSupabaseCreds({ url, key });
        } catch (error: any) {
            setConnectionError(error.message || 'Failed to connect. Please check credentials and try again.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const fetchEntries = async (currentUserId: string) => {
        try {
            const supabase = getSupabase();
            const { data, error } = await supabase
                .from('financial_entries')
                .select('*')
                .eq('user_id', currentUserId);

            if (error) throw error;
            setEntries(data || []);
            setFetchError(null);
        } catch (error: any) {
            console.error("Error fetching data:", error);
            
            let detailedErrorMessage = 'An unknown error occurred. Please check the console for more details.';
            if (error && typeof error === 'object' && error.message) {
                detailedErrorMessage = error.message;
            } else if (error) {
                detailedErrorMessage = String(error);
            }
            
            setFetchError(detailedErrorMessage);
            setEntries([]);
            throw error; // Re-throw to be caught by the connection handler
        }
    };
    
    useEffect(() => {
        let channel: RealtimeChannel | null = null;

        const connectAndFetch = async () => {
            if (!userId || !supabaseCreds) {
                if (!supabaseCreds) setIsLoading(false);
                return;
            };
            
            setIsLoading(true);
            setSupabaseStatus('connecting');
            setFetchError(null);

            try {
                // Initialize with confirmed credentials
                initializeSupabase(supabaseCreds.url, supabaseCreds.key);
                await fetchEntries(userId);
                setSupabaseStatus('connected');

                channel = getSupabase()
                    .channel('financial_entries')
                    .on('postgres_changes', { event: '*', schema: 'public', table: 'financial_entries' }, () => {
                        if (userId) fetchEntries(userId);
                    })
                    .subscribe();

            } catch (error) {
                setSupabaseStatus('error');
            } finally {
                setIsLoading(false);
            }
        };

        connectAndFetch();
        
        return () => {
            if (channel) {
                getSupabase()?.removeChannel(channel);
                channel = null;
            }
        };
    }, [userId, supabaseCreds]);

    const filteredEntries = useMemo(() => {
        return entries.filter(e => e.region === selectedRegion);
    }, [entries, selectedRegion]);

    const stocks = useMemo(() => filteredEntries.filter(e => e.type === 'stock'), [filteredEntries]);
    const mutualFunds = useMemo(() => filteredEntries.filter(e => e.type === 'mf'), [filteredEntries]);
    
    const clearCredentialsAndRetry = () => {
        localStorage.removeItem('supabase_url');
        localStorage.removeItem('supabase_key');
        setSupabaseCreds(null);
        setFetchError(null);
        setSupabaseStatus('idle');
        setConnectionError(null);
    };

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex justify-center items-center h-screen">
                    <div className="text-center">
                        <Clock className="h-12 w-12 mx-auto animate-spin text-indigo-500" />
                        <p className="mt-4 text-lg">Connecting to Database...</p>
                    </div>
                </div>
            );
        }

        if (fetchError) {
            return (
                <div className="p-4 sm:p-8 text-center max-w-4xl mx-auto">
                    <h2 className="text-3xl font-bold text-red-500 mb-4">Database Connection Error</h2>
                    <p className="mb-6 font-mono bg-red-500/10 text-red-400 p-3 rounded-md break-all">{fetchError}</p>
                    <div className={`p-6 rounded-lg text-left ${classes.card}`}>
                        <h3 className="text-xl font-semibold mb-4 text-indigo-400">How to Fix: Supabase Setup Guide</h3>
                        <p className="mb-4">
                            The error above suggests a problem with your database permissions, likely related to Row Level Security (RLS).
                            Follow these steps to resolve it.
                        </p>

                        <div className="mt-6 border-t border-current/10 pt-6">
                            <h4 className="font-bold text-lg mb-2">Option A: The Easy Fix (Disable RLS)</h4>
                            <p className="mb-2 text-sm text-current/80">For quick setup and testing, you can disable RLS for this table. This allows all requests with a valid anon key to succeed.</p>
                            <ol className="list-decimal list-inside space-y-2 text-sm">
                                <li>Go to your Supabase project dashboard.</li>
                                <li>Navigate to <strong>Authentication &rarr; Policies</strong>.</li>
                                <li>Find the <strong>financial_entries</strong> table and click on it.</li>
                                <li>Click the <strong>"Disable RLS"</strong> button.</li>
                            </ol>
                        </div>
                        
                        <div className="mt-8 border-t border-current/10 pt-6">
                            <h4 className="font-bold text-lg mb-2">Option B: The Recommended Fix (Enable RLS with Policies)</h4>
                            <p className="mb-2 text-sm text-current/80">If you want to keep RLS enabled, you must create policies that explicitly allow reading and writing data.</p>
                            <p className="font-semibold mb-2 text-sm">The Fastest Method: SQL Editor</p>
                            <ol className="list-decimal list-inside space-y-2 text-sm">
                                <li>In your Supabase dashboard, go to the <strong>SQL Editor</strong>.</li>
                                <li>Click <strong>"+ New query"</strong>.</li>
                                <li>Copy and paste the following commands and click <strong>"RUN"</strong>. This will delete any old policies and create the correct ones.</li>
                            </ol>
                            <div className={`mt-3 p-3 rounded-md font-mono text-xs overflow-x-auto ${theme === THEMES.DARK ? 'bg-gray-950' : 'bg-gray-100'}`}>
                                <pre className="whitespace-pre-wrap">
                                    <code>
{`-- Drop old policies if they exist, to start fresh
DROP POLICY IF EXISTS "Enable read access for all users" ON public.financial_entries;
DROP POLICY IF EXISTS "Enable insert for all users" ON public.financial_entries;
DROP POLICY IF EXISTS "Allow public read access" ON public.financial_entries;
DROP POLICY IF EXISTS "Allow public insert access" ON public.financial_entries;

-- Create policy to allow all users to read data
CREATE POLICY "Allow public read access"
ON public.financial_entries
FOR SELECT
USING (true);

-- Create policy to allow all users to insert data
CREATE POLICY "Allow public insert access"
ON public.financial_entries
FOR INSERT
WITH CHECK (true);`}
                                    </code>
                                </pre>
                            </div>
                            <p className="mt-4 text-sm text-current/70">After applying one of these fixes, refresh this page or click the button below to retry.</p>
                        </div>
                    </div>
                     <button 
                      onClick={clearCredentialsAndRetry}
                      className="mt-6 px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors"
                    >
                        Change Supabase Credentials
                    </button>
                </div>
            );
        }

        switch (activeView) {
            case VIEWS.DASHBOARD:
                return <DashboardView userId={userId} selectedRegion={selectedRegion} theme={theme} entries={filteredEntries} supabaseStatus={supabaseStatus} />;
            case VIEWS.STOCKS:
                return <StocksView stocks={stocks} selectedRegion={selectedRegion} theme={theme} />;
            case VIEWS.MUTUAL_FUNDS:
                return <MutualFundsView mutualFunds={mutualFunds} selectedRegion={selectedRegion} theme={theme} />;
            default:
                return <DashboardView userId={userId} selectedRegion={selectedRegion} theme={theme} entries={filteredEntries} supabaseStatus={supabaseStatus} />;
        }
    };
    
    if (!supabaseCreds) {
        return <SupabaseCredentialsModal onConnect={handleConnect} error={connectionError} theme={theme} />;
    }

    return (
        <div className={`min-h-screen font-sans transition-colors duration-300 ${classes.bg}`}>
            <Navigation
                activeView={activeView}
                setActiveView={setActiveView}
                selectedRegion={selectedRegion}
                setSelectedRegion={setSelectedRegion}
                theme={theme}
                setTheme={setTheme}
                setIsModalOpen={setIsModalOpen}
            />
            <main>
                {renderContent()}
            </main>
            <AddEntryModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                userId={userId}
                selectedRegion={selectedRegion}
                theme={theme}
            />
            <GeminiHelp entries={entries} theme={theme} />
        </div>
    );
};

export default App;