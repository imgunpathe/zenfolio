
import { ThemeClasses } from './types';

export const REGIONS = ['India', 'US', 'Europe', 'Japan'];

export const VIEWS = {
    DASHBOARD: 'Dashboard',
    STOCKS: 'Stocks',
    MUTUAL_FUNDS: 'Mutual Funds',
} as const;

export const THEMES = {
    LIGHT: 'light',
    DARK: 'dark',
    DIM: 'dim',
} as const;

export const CATEGORIES = ['Equity', 'Debt', 'Hybrid', 'Other'];

export const TIME_RANGES = ['1m', '6m', '1y', 'All'];

export const themeClasses: { [key: string]: ThemeClasses } = {
    light: {
        bg: 'bg-white text-gray-900',
        card: 'bg-white shadow-xl border border-gray-100 transition-shadow duration-300',
        nav: 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white',
        buttonActive: 'bg-white text-indigo-600 shadow-lg',
        buttonInactive: 'text-white/80 hover:bg-white/10',
        tableHeader: 'bg-gray-50',
    },
    dark: {
        bg: 'bg-gray-950 text-gray-50',
        card: 'bg-gray-900 shadow-2xl border border-indigo-900/50 transition-shadow duration-300',
        nav: 'bg-gradient-to-r from-gray-900 to-gray-800 text-white shadow-2xl',
        buttonActive: 'bg-indigo-600 text-white shadow-md',
        buttonInactive: 'text-gray-300 hover:bg-gray-800',
        tableHeader: 'bg-gray-800',
    },
    dim: {
        bg: 'bg-gray-800 text-gray-200',
        card: 'bg-gray-700 shadow-lg border border-gray-600 transition-shadow duration-300',
        nav: 'bg-gradient-to-r from-gray-700 to-gray-600 text-white shadow-xl',
        buttonActive: 'bg-indigo-500 text-white shadow-md',
        buttonInactive: 'text-gray-300 hover:bg-gray-600',
        tableHeader: 'bg-gray-600',
    }
};
