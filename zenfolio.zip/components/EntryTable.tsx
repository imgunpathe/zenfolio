
import React from 'react';
import { themeClasses, VIEWS } from '../constants';
import { FinancialEntry, Theme } from '../types';

interface EntryTableProps {
    title: string;
    headers: string[];
    data: FinancialEntry[];
    type: typeof VIEWS.STOCKS | typeof VIEWS.MUTUAL_FUNDS;
    theme: Theme;
}

const EntryTable: React.FC<EntryTableProps> = ({ title, headers, data, type, theme }) => {
    const classes = themeClasses[theme];
    
    const getRowStyle = (operation?: 'buy' | 'sell') => {
        if (operation === 'buy') return 'bg-green-50/50 text-green-800 dark:bg-green-900/30 dark:text-green-300';
        if (operation === 'sell') return 'bg-red-50/50 text-red-800 dark:bg-red-900/30 dark:text-red-300';
        return '';
    };

    if (data.length === 0) {
        return (
            <div className={`text-center p-8 rounded-xl shadow-inner mt-6 ${classes.card}`}>
                <p className="text-current/50">No {title.toLowerCase()} entries found for this region.</p>
            </div>
        );
    }

    return (
        <div className={`mt-6 rounded-xl shadow-lg overflow-hidden ${classes.card}`}>
            <h2 className={`text-xl font-bold p-4 ${classes.tableHeader} border-b border-current/10`}>{title} Entries ({data.length})</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-current/10">
                    <thead className={classes.tableHeader}>
                        <tr>
                            {headers.map((header) => (
                                <th
                                    key={header}
                                    className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-current/70"
                                >
                                    {header}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-current/10">
                        {data.map((item) => (
                            <tr key={item.id} className={getRowStyle(item.operation)}>
                                <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                                    {item.created_at ? new Date(item.created_at).toLocaleDateString() : 'N/A'}
                                </td>
                                <td className="px-4 py-3 whitespace-nowrap text-sm">{item.name}</td>
                                <td className="px-4 py-3 whitespace-nowrap text-sm font-semibold uppercase">{item.operation}</td>
                                
                                {type === VIEWS.STOCKS && 'price' in item && (
                                    <>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm">${item.price?.toFixed(2) || 'N/A'}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm">{item.quantity}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm font-bold">${(item.price * item.quantity).toFixed(2)}</td>
                                    </>
                                )}
                                
                                {type === VIEWS.MUTUAL_FUNDS && 'nav' in item && (
                                    <>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm uppercase">{item.category}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm">{item.units?.toFixed(3) || 'N/A'}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm">${item.nav?.toFixed(4) || 'N/A'}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm font-bold">${item.amount?.toFixed(2) || 'N/A'}</td>
                                    </>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default EntryTable;