
import { useMemo } from 'react';
import { FinancialEntry, StockEntry, MutualFundEntry } from '../types';

export const useFinancialMetrics = (entries: FinancialEntry[]) => {
    const metrics = useMemo(() => {
        if (entries.length === 0) {
            return {
                totalInvested: 0,
                portfolioValue: 0,
                unrealizedPNL: 0,
                pnlPercentage: 0,
                assetAllocationData: [],
                valueOverTimeData: [],
            };
        }

        const sortedEntries = [...entries].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        
        const holdings: { [key: string]: { quantity: number; type: 'stock' | 'mf'; totalCost: number } } = {};
        const latestPrices: { [key: string]: number } = {};
        let totalInvested = 0;

        sortedEntries.forEach(entry => {
            if (!holdings[entry.name]) {
                holdings[entry.name] = { quantity: 0, type: entry.type, totalCost: 0 };
            }

            if (entry.operation === 'buy') {
                if (entry.type === 'stock') {
                    holdings[entry.name].quantity += entry.quantity;
                    const cost = entry.price * entry.quantity;
                    holdings[entry.name].totalCost += cost;
                    totalInvested += cost;
                    latestPrices[entry.name] = entry.price;
                } else {
                    holdings[entry.name].quantity += entry.units;
                    holdings[entry.name].totalCost += entry.amount;
                    totalInvested += entry.amount;
                    latestPrices[entry.name] = entry.nav;
                }
            } else { // sell
                if (entry.type === 'stock') {
                    holdings[entry.name].quantity -= entry.quantity;
                    latestPrices[entry.name] = entry.price;
                } else {
                    holdings[entry.name].quantity -= entry.units;
                    latestPrices[entry.name] = entry.nav;
                }
            }
        });

        const portfolioValue = Object.entries(holdings).reduce((acc, [name, holding]) => {
            const price = latestPrices[name] || 0;
            const value = holding.quantity * price;
            return acc + value;
        }, 0);
        
        const unrealizedPNL = portfolioValue - totalInvested;
        const pnlPercentage = totalInvested > 0 ? (unrealizedPNL / totalInvested) * 100 : 0;

        const assetAllocationData = [
            { name: 'Stocks', value: 0, fill: '#6366F1' },
            { name: 'Mutual Funds', value: 0, fill: '#10B981' },
        ];

        Object.entries(holdings).forEach(([name, holding]) => {
            const value = holding.quantity * (latestPrices[name] || 0);
            if (holding.type === 'stock') {
                assetAllocationData[0].value += value;
            } else {
                assetAllocationData[1].value += value;
            }
        });

        const valueOverTimeData: { date: string, value: number }[] = [];
        let runningHoldings: { [key: string]: { quantity: number } } = {};
        let runningPrices: { [key: string]: number } = {};
        
        sortedEntries.forEach(entry => {
            if (!runningHoldings[entry.name]) {
                 runningHoldings[entry.name] = { quantity: 0 };
            }
            if (entry.operation === 'buy') {
                runningHoldings[entry.name].quantity += (entry as StockEntry).quantity || (entry as MutualFundEntry).units;
            } else {
                runningHoldings[entry.name].quantity -= (entry as StockEntry).quantity || (entry as MutualFundEntry).units;
            }
            runningPrices[entry.name] = (entry as StockEntry).price || (entry as MutualFundEntry).nav;
            
            const currentValue = Object.entries(runningHoldings).reduce((acc, [name, holding]) => {
                return acc + (holding.quantity * (runningPrices[name] || 0));
            }, 0);

            valueOverTimeData.push({
                date: new Date(entry.created_at).toLocaleDateString(),
                value: currentValue
            });
        });

        return {
            totalInvested,
            portfolioValue,
            unrealizedPNL,
            pnlPercentage,
            assetAllocationData: assetAllocationData.filter(d => d.value > 0),
            valueOverTimeData,
        };
    }, [entries]);

    return metrics;
};
