
import React from 'react';
import { List } from 'lucide-react';
import EntryTable from './EntryTable';
import { VIEWS } from '../constants';
import { FinancialEntry, Theme } from '../types';

interface MutualFundsViewProps {
    mutualFunds: FinancialEntry[];
    selectedRegion: string;
    theme: Theme;
}

const MutualFundsView: React.FC<MutualFundsViewProps> = ({ mutualFunds, selectedRegion, theme }) => {
    return (
        <div className="p-4 sm:p-8">
            <h1 className="text-4xl font-extrabold text-indigo-500 mb-6 flex items-center">
                <List className="mr-3 h-9 w-9" />
                Mutual Funds ({selectedRegion})
            </h1>
            <EntryTable
                title="Mutual Fund"
                headers={['Date', 'Name', 'Operation', 'Category', 'Units', 'NAV', 'Total Amount']}
                data={mutualFunds}
                type={VIEWS.MUTUAL_FUNDS}
                theme={theme}
            />
        </div>
    );
};

export default MutualFundsView;