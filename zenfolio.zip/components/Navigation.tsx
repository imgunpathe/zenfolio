
import React from 'react';
import { Compass, Plus } from 'lucide-react';
import { VIEWS, REGIONS, themeClasses } from '../constants';
import ThemeToggle from './ThemeToggle';
import { View, Theme } from '../types';

interface NavigationProps {
    activeView: View;
    setActiveView: (view: View) => void;
    selectedRegion: string;
    setSelectedRegion: (region: string) => void;
    theme: Theme;
    setTheme: (theme: Theme) => void;
    setIsModalOpen: (isOpen: boolean) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeView, setActiveView, selectedRegion, setSelectedRegion, theme, setTheme, setIsModalOpen }) => {
    const classes = themeClasses[theme];

    return (
        <nav className={`flex flex-col sm:flex-row justify-between items-center p-4 ${classes.nav} shadow-lg sticky top-0 z-10`}>
            <div className="flex space-x-2 sm:space-x-4 mb-3 sm:mb-0">
                {Object.values(VIEWS).map((view) => (
                    <button
                        key={view}
                        onClick={() => setActiveView(view)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                            activeView === view
                                ? classes.buttonActive
                                : classes.buttonInactive
                        }`}
                    >
                        {view}
                    </button>
                ))}
            </div>

            <div className="flex items-center space-x-4">
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-semibold shadow-md transition-all duration-300 transform hover:scale-105"
                >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Entry
                </button>

                <div className="hidden sm:flex items-center space-x-2">
                    <Compass className="h-5 w-5 text-white/90" />
                    <select
                        value={selectedRegion}
                        onChange={(e) => setSelectedRegion(e.target.value)}
                        className="p-2 border border-white/30 rounded-lg text-sm bg-white/10 text-white focus:ring-indigo-300 focus:border-indigo-300 transition-shadow shadow-inner"
                    >
                        {REGIONS.map((region) => (
                            <option key={region} value={region} className="bg-gray-800 text-white">
                                {region}
                            </option>
                        ))}
                    </select>
                </div>

                <ThemeToggle theme={theme} setTheme={setTheme} />
            </div>
        </nav>
    );
};

export default Navigation;