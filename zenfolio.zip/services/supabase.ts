import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseInstance: SupabaseClient | null = null;

export const initializeSupabase = (url: string, key: string): SupabaseClient => {
    if (!url || !key || !url.startsWith('http')) {
        throw new Error('Invalid Supabase URL or Anon Key provided.');
    }
    
    try {
        supabaseInstance = createClient(url, key);
        return supabaseInstance;
    } catch (error) {
        console.error("Error initializing Supabase client:", error);
        supabaseInstance = null;
        throw error;
    }
};

export const getSupabase = (): SupabaseClient => {
    if (!supabaseInstance) {
        throw new Error('Supabase has not been initialized. Please ensure credentials are set correctly.');
    }
    return supabaseInstance;
};
