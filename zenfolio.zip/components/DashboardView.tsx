import React from 'react';
import { LineChart, LoaderCircle, CheckCircle2, XCircle } from 'lucide-react';
import { themeClasses, THEMES } from '../constants';
import { useFinancialMetrics } from '../hooks/useFinancialMetrics';
import { FinancialEntry, Theme } from '../types';
import PortfolioChart from './PortfolioChart';
import MetricCard from './MetricCard';

type SupabaseStatus = 'idle' | 'connecting' | 'connected' | 'error';

interface DashboardViewProps {
    userId: string | null;
    selectedRegion: string;
    theme: Theme;
    entries: FinancialEntry[];
    supabaseStatus: SupabaseStatus;
}

const DashboardView: React.FC<DashboardViewProps> = ({ userId, selectedRegion, theme, entries, supabaseStatus }) => {
    const classes = themeClasses[theme];
    const { totalInvested, portfolioValue, unrealizedPNL, pnlPercentage, assetAllocationData, valueOverTimeData } = useFinancialMetrics(entries);

    const renderStatusIndicator = () => {
        switch (supabaseStatus) {
            case 'connecting':
                return (
                    <div className="flex items-center text-yellow-400 font-semibold">
                        <LoaderCircle className="animate-spin h-5 w-5 mr-2" /> Connecting to Supabase...
                    </div>
                );
            case 'connected':
                return (
                    <div className="flex items-center text-green-400 font-semibold">
                        <CheckCircle2 className="h-5 w-5 mr-2" /> Connected to Supabase
                    </div>
                );
            case 'error':
                 return (
                    <div className="flex items-center text-red-400 font-semibold">
                        <XCircle className="h-5 w-5 mr-2" /> Connection Failed
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="p-4 sm:p-8">
            <h1 className="text-4xl font-extrabold text-indigo-500 mb-6">
                <LineChart className="inline-block mr-3 h-9 w-9" />
                Financial Overview
            </h1>
            <div className={`p-6 rounded-xl shadow-xl border ${classes.card} border-indigo-500/50`}>
                <h2 className="text-2xl font-semibold text-indigo-400 mb-4">Welcome Back!</h2>
                <div className="space-y-4">
                    <p>This dashboard tracks your financial entries for the <strong>{selectedRegion}</strong> region.</p>
                    <div className={`mt-2 p-3 rounded-lg text-sm font-mono break-all ${theme === THEMES.DARK ? 'bg-gray-800 text-indigo-300' : 'bg-indigo-100 text-indigo-800'}`}>
                        <strong className="font-bold">Authenticated User ID:</strong> {userId}
                    </div>
                     <div className={`mt-2 p-3 rounded-lg text-sm ${theme === THEMES.DARK ? 'bg-gray-800' : 'bg-indigo-100'}`}>
                        {renderStatusIndicator()}
                    </div>
                </div>
            </div>

            <div className="mt-8">
                <h3 className="text-xl font-semibold text-indigo-400 mb-4">Key Metrics Summary</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <MetricCard label="Invested Capital" value={totalInvested} cardClass={classes.card} subtext="All Time" />
                    <MetricCard 
                        label="Current Portfolio Value" 
                        value={portfolioValue} 
                        cardClass={classes.card} 
                        pnl={unrealizedPNL}
                        pnlPercentage={pnlPercentage}
                        subtext="Unrealized P&L"
                    />
                     <MetricCard 
                        label="Unrealized P&L" 
                        value={unrealizedPNL} 
                        cardClass={classes.card} 
                        pnl={unrealizedPNL}
                        pnlPercentage={pnlPercentage}
                        subtext="Total Return"
                    />
                </div>
            </div>

            <PortfolioChart theme={theme} assetAllocationData={assetAllocationData} valueOverTimeData={valueOverTimeData} />
        </div>
    );
};

export default DashboardView;
