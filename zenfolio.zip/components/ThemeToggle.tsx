
import React from 'react';
import { Sun, Moon, Zap } from 'lucide-react';
import { THEMES } from '../constants';
import { Theme } from '../types';

interface ThemeToggleProps {
    theme: Theme;
    setTheme: (theme: Theme) => void;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ theme, setTheme }) => {
    const ThemeButton = ({ currentTheme, icon: Icon, label }: { currentTheme: Theme, icon: React.ElementType, label: string }) => (
        <button
            onClick={() => setTheme(currentTheme)}
            className={`p-2 rounded-full transition-colors duration-200 ${
                theme === currentTheme
                    ? 'bg-white text-indigo-600 shadow-lg'
                    : 'text-white/70 hover:bg-white/20'
            }`}
            aria-label={`Switch to ${label} Theme`}
            title={label}
        >
            <Icon className="h-5 w-5" />
        </button>
    );

    return (
        <div className="flex items-center space-x-2">
            <ThemeButton currentTheme={THEMES.LIGHT} icon={Sun} label="Light" />
            <ThemeButton currentTheme={THEMES.DARK} icon={Moon} label="Dark" />
            <ThemeButton currentTheme={THEMES.DIM} icon={Zap} label="Dim" />
        </div>
    );
};

export default ThemeToggle;