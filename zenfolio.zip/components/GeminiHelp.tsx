import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, LoaderCircle } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { FinancialEntry, Theme } from '../types';
import { themeClasses } from '../constants';

interface GeminiHelpProps {
    entries: FinancialEntry[];
    theme: Theme;
}

interface Message {
    sender: 'user' | 'model';
    text: string;
}

const GeminiHelp: React.FC<GeminiHelpProps> = ({ entries, theme }) => {
    if (!process.env.API_KEY) {
        console.warn("Gemini features disabled: API_KEY is not configured.");
        return null; // Don't render the button if the API key isn't available
    }

    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const chatContainerRef = useRef<HTMLDivElement>(null);
    const classes = themeClasses[theme];

    // Auto-scroll to bottom of chat
    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputValue.trim() || isThinking) return;

        const userMessage: Message = { sender: 'user', text: inputValue };
        setMessages(prev => [...prev, userMessage]);
        setInputValue('');
        setIsThinking(true);
        setError(null);

        try {
            if (!process.env.API_KEY) {
              throw new Error("API_KEY environment variable not set.");
            }
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            const portfolioData = entries.length > 0 ? JSON.stringify(entries, null, 2) : "The user has no portfolio data yet.";
            
            const prompt = `
                You are ZenFolio AI, a helpful and friendly financial assistant for the ZenFolio app.
                Your goal is to provide insightful analysis and answer questions based on the user's portfolio data.
                Keep your answers concise, clear, and easy to understand.
                If the user asks a general financial question, answer it, but always try to relate it back to their portfolio if possible.
                Do not provide financial advice, but you can offer analysis and explanations.
                
                Here is the user's portfolio data in JSON format:
                ${portfolioData}

                ---

                User's question: "${userMessage.text}"
            `;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });
            
            const modelMessage: Message = { sender: 'model', text: response.text };
            setMessages(prev => [...prev, modelMessage]);

        } catch (err: any) {
            console.error("Gemini API error:", err);
            const errorMessage = "Sorry, I couldn't connect to the AI assistant. Please check your API key and network connection.";
            setError(errorMessage);
            setMessages(prev => [...prev, { sender: 'model', text: errorMessage }]);
        } finally {
            setIsThinking(false);
        }
    };

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-6 right-6 z-40 p-4 bg-indigo-600 text-white rounded-full shadow-lg hover:bg-indigo-700 transition-transform transform hover:scale-110"
                aria-label="Ask Gemini AI"
                title="Ask Gemini AI"
            >
                <Bot className="h-6 w-6" />
            </button>

            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={() => setIsOpen(false)}>
                    <div
                        className={`w-full max-w-2xl h-[80vh] flex flex-col rounded-xl shadow-2xl m-4 transform transition-all ${classes.card}`}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center p-4 border-b border-current/20">
                            <h2 className="text-xl font-bold text-indigo-500 flex items-center">
                                <Bot className="h-6 w-6 mr-2" /> Ask ZenFolio AI
                            </h2>
                            <button onClick={() => setIsOpen(false)} className="p-2 rounded-full hover:bg-current/10 transition-colors">
                                <X className="h-6 w-6 text-current/70" />
                            </button>
                        </div>

                        <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto space-y-4">
                            {messages.length === 0 && (
                                <div className="text-center text-current/60 p-8">
                                    <p className="font-semibold">Welcome!</p>
                                    <p>Ask me anything about your portfolio.</p>
                                    <p className="text-xs mt-2">e.g., "What's my best performing stock?" or "Summarize my mutual fund investments."</p>
                                </div>
                            )}
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-md p-3 rounded-lg ${
                                        msg.sender === 'user'
                                            ? 'bg-indigo-600 text-white'
                                            : `${classes.tableHeader}`
                                    }`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                            {isThinking && (
                                <div className="flex justify-start">
                                    <div className={`p-3 rounded-lg ${classes.tableHeader} inline-flex items-center`}>
                                        <LoaderCircle className="h-4 w-4 animate-spin mr-2" />
                                        <p className="text-sm">Thinking...</p>
                                    </div>
                                </div>
                            )}
                        </div>
                        
                        {error && <div className="p-2 mx-4 bg-red-500/10 border border-red-400 text-red-400 rounded-lg text-sm">{error}</div>}

                        <div className="p-4 border-t border-current/20">
                            <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
                                <input
                                    type="text"
                                    value={inputValue}
                                    onChange={(e) => setInputValue(e.target.value)}
                                    placeholder="Ask about your portfolio..."
                                    className={`flex-1 p-3 rounded-lg border focus:ring-indigo-500 focus:border-indigo-500 transition-shadow text-gray-900 bg-gray-100 border-gray-300`}
                                    disabled={isThinking}
                                />
                                <button
                                    type="submit"
                                    disabled={!inputValue.trim() || isThinking}
                                    className="p-3 bg-indigo-600 text-white rounded-lg disabled:opacity-50 hover:bg-indigo-700 transition-colors"
                                >
                                    <Send className="h-5 w-5" />
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default GeminiHelp;