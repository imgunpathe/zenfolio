
import React, { useState } from 'react';
import { PieChart as RechartsPieChart, Pie, Cell, Tooltip, Legend, LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { PieChart, LineChart as LineChartIcon } from 'lucide-react';
import { themeClasses, TIME_RANGES } from '../constants';
import { Theme } from '../types';

interface ChartProps {
    theme: Theme;
    assetAllocationData: { name: string; value: number; fill: string }[];
    valueOverTimeData: { date: string; value: number }[];
}

const PortfolioChart: React.FC<ChartProps> = ({ theme, assetAllocationData, valueOverTimeData }) => {
    const classes = themeClasses[theme];
    const [timeRange, setTimeRange] = useState('All'); // For future filtering logic
    const isDark = theme !== 'light';
    const textColor = isDark ? '#E5E7EB' : '#1F2937';

    const totalAssets = assetAllocationData.reduce((sum, item) => sum + item.value, 0);

    const CustomTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            if (payload[0].name) { // Pie chart tooltip
                return (
                    <div className="p-2 bg-gray-700 text-white rounded-md shadow-lg border border-gray-600">
                        <p className="font-bold">{`${payload[0].name}`}</p>
                        <p>{`Value: $${payload[0].value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</p>
                        <p>{`Percentage: ${((payload[0].value / totalAssets) * 100).toFixed(2)}%`}</p>
                    </div>
                );
            }
            // Line chart tooltip
            return (
                 <div className="p-2 bg-gray-700 text-white rounded-md shadow-lg border border-gray-600">
                    <p className="font-bold">{`Date: ${label}`}</p>
                    <p>{`Portfolio Value: $${payload[0].value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</p>
                </div>
            );
        }
        return null;
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            <div className={`lg:col-span-1 p-6 rounded-xl ${classes.card}`}>
                <h3 className="text-xl font-bold mb-4 flex items-center text-indigo-400">
                    <PieChart className="h-5 w-5 mr-2" />
                    Asset Split
                </h3>
                {assetAllocationData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                        <RechartsPieChart>
                            <Pie data={assetAllocationData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                {assetAllocationData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                            </Pie>
                            <Tooltip content={<CustomTooltip />}/>
                            <Legend wrapperStyle={{ color: textColor }}/>
                        </RechartsPieChart>
                    </ResponsiveContainer>
                ) : <p className="text-center text-current/50 h-[300px] flex items-center justify-center">No assets to display.</p>}
            </div>

            <div className={`lg:col-span-2 p-6 rounded-xl ${classes.card}`}>
                <h3 className="text-xl font-bold mb-4 flex items-center text-indigo-400">
                    <LineChartIcon className="h-5 w-5 mr-2" />
                    Portfolio Value Over Time
                </h3>
                <div className={`flex space-x-2 p-1 rounded-lg w-full mb-4 ${classes.tableHeader}`}>
                    {TIME_RANGES.map(range => (
                        <button key={range} onClick={() => setTimeRange(range)} className={`flex-1 py-1 text-sm font-medium rounded-md transition-colors ${timeRange === range ? 'bg-indigo-600 text-white shadow-md' : 'text-current/70 hover:bg-current/10'}`}>
                            {range}
                        </button>
                    ))}
                </div>
                 {valueOverTimeData.length > 1 ? (
                    <ResponsiveContainer width="100%" height={300}>
                        <RechartsLineChart data={valueOverTimeData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#4B5563' : '#E5E7EB'} />
                            <XAxis dataKey="date" tick={{ fill: textColor }} />
                            <YAxis tickFormatter={(value) => `$${(value/1000)}k`} tick={{ fill: textColor }} />
                            <Tooltip content={<CustomTooltip />} />
                            <Line type="monotone" dataKey="value" stroke="#8884d8" strokeWidth={2} dot={false} />
                        </RechartsLineChart>
                    </ResponsiveContainer>
                ) : <p className="text-center text-current/50 h-[300px] flex items-center justify-center">Not enough data for a chart.</p>}
            </div>
        </div>
    );
};

export default PortfolioChart;